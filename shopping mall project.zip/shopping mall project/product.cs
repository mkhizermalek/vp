﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace shopping_mall_project
{
    public partial class product : Form
    {
        public SqlConnection con = new SqlConnection("Data Source=KUNKNOWN\\SQLEXPRESS;Initial Catalog=shoppingmall;Integrated Security=True;");
        string ImageDbPath = null;
        public product()
        {
            InitializeComponent();
            admingrid();
            FillBrands();
            FillCategories();
        }
        void FillBrands()
        {
            SqlCommand cmd = new SqlCommand("select * from brands", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            combobrand.Items.Clear();
            combobrand.DataSource = dt;

            combobrand.DisplayMember = "name";
            combobrand.ValueMember = "id";


        }

        void FillCategories()
        {
            SqlCommand cmd = new SqlCommand("select * from categories", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            combocategory.Items.Clear();
            combocategory.DataSource = dt;

            combocategory.DisplayMember = "name";
            combocategory.ValueMember = "id";


        }
        void admingrid()
        {
            SqlCommand cmd = new SqlCommand("select * from product", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            dataGridAdmin.DataSource = dt;
        }
        private void btnadd_Click(object sender, EventArgs e)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("INSERT INTO product VALUES('" + txtname.Text + "','" + txtdetails.Text + "','"+ ImageDbPath + "','"+ txtprice + "','"+ txtqty + "','"+ combocategory.SelectedValue + "','"+ combobrand.SelectedValue + "')", con);
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();

                txtname.Text = " ";
                txtdetails.Text = " ";
                lblimage.Text = " ";
                picboxgridpage.Image = null;

                admingrid();
                MessageBox.Show(txtname.Text+" Added succesfully", "Message");
            }
            catch(Exception ex)
            {
                MessageBox.Show("Not added succesfully /n Error: "+ex.Message);
            }
        }
       

        private void dataGridAdmin_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            admingrid();
        }

        private void btnedit_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand("Select * From product WHERE Id = '" + txtid.Text + "'", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);

            DataTable dt = new DataTable();
            da.Fill(dt);

            if (dt.Rows.Count == 0)
            {
                MessageBox.Show("Data not found for Id : " + txtid.Text, "Not Found");
                return;
            }

            txtname.Text = dt.Rows[0][1].ToString();
            txtdetails.Text = dt.Rows[0][2].ToString();

            txtid.Enabled = false;
            btnadd.Enabled = false;
            btndelete.Enabled = false;
            btnedit.Visible = false;
            btnupdate.Visible = true;
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            SqlCommand cmd1 = new SqlCommand("UPDATE product SET Name = '" + txtname.Text + "',Details = '" + txtdetails.Text + "' Where id = '" + txtid.Text + "'", con);
            con.Open();
            cmd1.ExecuteNonQuery();
            con.Close();
            admingrid();



            MessageBox.Show("Item Updated successfully.", "Message");
        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand("Select * From product WHERE Id = '" + txtid.Text + "'", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);

            DataTable dt = new DataTable();
            da.Fill(dt);

            if (dt.Rows.Count == 0)
            {
                MessageBox.Show("Data not found for Id : " + txtid.Text, "Not Found");
                return;
            }

            SqlCommand cmd1 = new SqlCommand("DELETE FROM product Where id = '" + txtid.Text + "'", con);
            con.Open();
            cmd1.ExecuteNonQuery();
            con.Close();
            admingrid();


            MessageBox.Show("Item Deleted successfully.", "Message");
        }

        private void btnimage_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "image files|*.jpg;*.png*.bmp";
            if(ofd.ShowDialog() == DialogResult.OK)
            {
                string filenameonly = Path.GetFileName(ofd.FileName);
                string destpath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "image", filenameonly);
                Directory.CreateDirectory(Path.GetDirectoryName(destpath));
                File.Copy(ofd.FileName, destpath, true);
                picboxgridpage.ImageLocation = destpath;
                lblimage.Text = filenameonly;

                ImageDbPath = filenameonly;
            }
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void txtid_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
