﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace shopping_mall_project
{
    public partial class gridpage : Form
    {
        public SqlConnection con = new SqlConnection("Data Source=KUNKNOWN\\SQLEXPRESS;Initial Catalog=shoppingmall;Integrated Security=True;");
        string ImageDbPath = null;
        public gridpage()
        {
            InitializeComponent();
            admingrid();
        }
        void admingrid()
        {
            SqlCommand cmd = new SqlCommand("select * from admin", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            dataGridAdmin.DataSource = dt;
        }
        private void btnadd_Click(object sender, EventArgs e)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("INSERT INTO admin VALUES('" + txtname.Text + "','" + txtdetails.Text + "','"+ ImageDbPath + "')", con);
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();

                txtname.Text = " ";
                txtdetails.Text = " ";
                lblimage.Text = " ";
                picboxgridpage.Image = null;

                admingrid();
                MessageBox.Show(txtname.Text+" Added succesfully", "Message");
            }
            catch(Exception ex)
            {
                MessageBox.Show("Not added succesfully /n Error: "+ex.Message);
            }
        }
        

        private void dataGridAdmin_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            admingrid();
        }

        private void btnedit_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand("Select * From admin WHERE Id = '" + txtid.Text + "'", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);

            DataTable dt = new DataTable();
            da.Fill(dt);

            if (dt.Rows.Count == 0)
            {
                MessageBox.Show("Data not found for Id : " + txtid.Text, "Not Found");
                return;
            }

            txtname.Text = dt.Rows[0][1].ToString();
            txtdetails.Text = dt.Rows[0][2].ToString();

            txtid.Enabled = false;
            btnadd.Enabled = false;
            btndelete.Enabled = false;
            btnedit.Visible = false;
            btnupdate.Visible = true;
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            SqlCommand cmd1 = new SqlCommand("UPDATE admin SET Name = '" + txtname.Text + "',Details = '" + txtdetails.Text + "' Where id = '" + txtid.Text + "'", con);
            con.Open();
            cmd1.ExecuteNonQuery();
            con.Close();
            admingrid();



            MessageBox.Show("Item Updated successfully.", "Message");


            txtname.Text = " ";
            txtdetails.Text = " ";
            lblimage.Text = " ";
            txtid.Text = " ";
            picboxgridpage.Image = null;
            btnupdate.Visible=false;
            btnedit.Visible = true;
            txtid.Enabled = true;
            btnadd.Enabled = true;
            btndelete.Enabled = true;
        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand("Select * From admin WHERE Id = '" + txtid.Text + "'", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);

            DataTable dt = new DataTable();
            da.Fill(dt);

            if (dt.Rows.Count == 0)
            {
                MessageBox.Show("Data not found for Id : " + txtid.Text, "Not Found");
                return;
            }

            SqlCommand cmd1 = new SqlCommand("DELETE FROM admin Where id = '" + txtid.Text + "'", con);
            con.Open();
            cmd1.ExecuteNonQuery();
            con.Close();
            admingrid();


            MessageBox.Show("Item Deleted successfully.", "Message");
        }

        private void btnimage_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "image files|*.jpg;*.png*.bmp";
            if(ofd.ShowDialog() == DialogResult.OK)
            {
                string filenameonly = Path.GetFileName(ofd.FileName);
                string destpath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "image", filenameonly);
                Directory.CreateDirectory(Path.GetDirectoryName(destpath));
                File.Copy(ofd.FileName, destpath, true);
                picboxgridpage.ImageLocation = destpath;
                lblimage.Text = filenameonly;

                ImageDbPath = filenameonly;
            }
        }

        private void btnview_Click(object sender, EventArgs e)
        {
            product p = new product();
            p.ShowDialog();
            this.Close();
        }
    }
}
