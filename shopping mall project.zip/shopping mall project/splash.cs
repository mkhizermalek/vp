﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace shopping_mall_project
{
    public partial class splash : Form
    {
        private int progress = 0;
        public splash()
        {
            InitializeComponent();
            timer1.Interval = 50;
            timer1.Start();
        }
        
        private void progressBar1_Click(object sender, EventArgs e)
        {
            
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            progress += 5;
            if(progress >= 100)
            {
                this.Close();
            }
            progressBar1.Value = progress;
            label1.Text= progress.ToString() + "%";
        }
    }
}
