﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace shopping_mall_project
{
    public partial class register : Form
    {
        public SqlConnection con = new SqlConnection("Data Source=KUNKNOWN\\SQLEXPRESS;Initial Catalog=shoppingmall;Integrated Security=True");
        public register()
        {
            InitializeComponent();
            grid();
        }

        void grid()
        {
            SqlCommand cmd = new SqlCommand("select * from users", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            //dataGridAdmin.DataSource = dt;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            

            //empty field validation
            if (string.IsNullOrEmpty(txtname.Text) || string.IsNullOrEmpty(txtemail.Text) || string.IsNullOrEmpty(txtpassword.Text) || string.IsNullOrEmpty(txtconfirmpass.Text))
            {
                MessageBox.Show("please filled all fields", "empty fields");
                return;
            }

            //password matching validation
            if (txtconfirmpass.Text != txtpassword.Text)
            {
                MessageBox.Show("password not match", "error");
                return;
            }

            //regular expression validation
            if (!Regex.IsMatch(txtemail.Text, "^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\\.[a-zA-Z0-9-.]+$"))
            {
                MessageBox.Show("invalid email format", "error");
                return;
            }

            // data insertion in database
            
            SqlCommand cmd = new SqlCommand("INSERT INTO users VALUES('" + txtname.Text + "', '" + txtemail.Text + "', '" + txtpassword.Text + "')",con);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();

            login login22 = new login();
            login22.ShowDialog();
            this.Close();
            
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void DataGridCats_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            grid();
        }
    }
}
